# Ethical Hacking Project Internshala Training Program
 This Project was created by me during the Training Program of Ethical Hacking by Internshala Training Platform
## What I did in the Project
> - Tested a demo E-commerce website
> - Hunted for the Bugs and Vulnerabilities in them
> - Searched Exploits for the vulnerabilities
> - Suggested Patches for the website
> - Created a Detailed Developer Report on Vulnerabilities Found
---
